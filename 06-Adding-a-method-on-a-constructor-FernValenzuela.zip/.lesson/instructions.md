# Instructions  

1. Create a method on the constructor function and call it `summarizeHotel`.
2. Have the method log out this sentence: "One night at the <HOTEL NAME> for two adults and two children will cost <PRICE> credits."
3. Keep in mind you'll need some logic in your method to calculate the price.
  